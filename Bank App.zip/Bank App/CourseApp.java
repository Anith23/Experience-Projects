class Student {
    private String name;
    private String gender;
    private String registrationNumber;
    private int academicYear;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public int getAcademicYear() {
        return academicYear;
    }

    public Student(String name, String gender, String registrationNumber, int academicYear) {
        this.name = name;
        this.gender = gender;
        this.registrationNumber = registrationNumber;
        this.academicYear = academicYear;
    }
}

class Course {
    private String courseName;
    private int credits;
    private String incharge;
    private int totalHours;

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public String getIncharge() {
        return incharge;
    }

    public void setIncharge(String incharge) {
        this.incharge = incharge;
    }

    public int getTotalHours() {
        return totalHours;
    }

    public void setTotalHours(int totalHours) {
        this.totalHours = totalHours;
    }

    public Course(String courseName, int credits, String incharge, int totalHours) {
        this.courseName = courseName;
        this.credits = credits;
        this.incharge = incharge;
        this.totalHours = totalHours;
    }

    public boolean checkCourse(String partialName) {
        return courseName.toLowerCase().contains(partialName.toLowerCase());
    }

    public void checkDuration() {
        if (totalHours > 15) {
            System.out.println("The duration exceeds the limit");
        } else {
            System.out.println("Duration is limited");
        }
    }

    public void printCourseDetails() {
        System.out.println("Course Name: " + courseName);
        System.out.println("Credits: " + credits);
        System.out.println("In-charge: " + incharge);
        System.out.println("Total Hours: " + totalHours);
    }
}

class Grade extends Course {
    private boolean noncredit = false;

    public Grade(String courseName, int credits, String incharge, int totalHours) {
        super(courseName, credits, incharge, totalHours);
    }

    public void checkCredits() {
        if (noncredit) {
            System.out.println("Non credit subject");
        }
    }
}

class CourseApp {
    public static void main(String[] args) {
        // Creating objects for Student, Course, and Grade
        Student student = new Student("John Doe", "Male", "12345", 2023);
        Course course = new Course("Mathematics", 3, "Prof. Smith", 12);
        Grade grade = new Grade("Physics", 2, "Prof. Johnson", 18);

        // Calling methods on Course and Grade objects
        System.out.println("Student Details:");
        System.out.println("Name: " + student.getName());
        System.out.println("Gender: " + student.getGender());
        System.out.println("Registration Number: " + student.getRegistrationNumber());
        System.out.println("Academic Year: " + student.getAcademicYear());

        System.out.println("\nCourse Details:");
        course.printCourseDetails();
        course.checkDuration();
        System.out.println("Is 'Math' available? " + course.checkCourse("Math"));

        System.out.println("\nGrade Details:");
        grade.printCourseDetails();
        grade.checkDuration();
        grade.checkCredits();
    }
}
