class BankAccount {
    String accHolderName;
    double balance;
    double minimumBalance = 500;
    double annualInterest;

    // Default constructor
    BankAccount() {
        accHolderName = null;
        balance = 0;
        annualInterest = 0;
    }

    // Parameterized constructor
    BankAccount(String name, double newBalance) {
        accHolderName = name;
        balance = newBalance;
    }

    void checkDeposit(double initialDeposit) {
        if (initialDeposit < minimumBalance) {
            System.out.println("Please deposit more money.");
        }
    }

    void deposit(double amount) {
        balance += amount;
    }

    double withdraw(double amount) {
        if (balance < amount + minimumBalance) {
            System.out.println("Insufficient balance.");
            return 0;
        } else {
            balance -= amount;
            return amount;
        }
    }

    void checkBalance() {
        System.out.println("Account Holder: " + accHolderName);
        System.out.println("Balance: " + balance);
    }
}

class SavingsAccount extends BankAccount {
    SavingsAccount(String name, double newBalance) {
        super(name, newBalance);
    }

    
    void checkBalance() {
        System.out.println("This is a savings account");
        super.checkBalance();
    }
}

public class BankApp {
    public static void main(String[] args) {
        SavingsAccount account1 = new SavingsAccount("Ani", 1000);
        SavingsAccount account2 = new SavingsAccount("Thars", 1500);

        account1.deposit(500);
        account2.deposit(1000);

        account1.checkBalance();
        account2.checkBalance();

        double withdrawalAmount1 = account1.withdraw(300);
        if (withdrawalAmount1 > 0) {
            System.out.println("Withdrawn amount from account1: " + withdrawalAmount1);
        } else {
            System.out.println("Withdrawal from account1 failed.");
        }

        account1.checkBalance();
        
        double withdrawalAmount2 = account2.withdraw(2000);
        if (withdrawalAmount2 > 0) {
            System.out.println("Withdrawn amount from account2: " + withdrawalAmount2);
        } else {
            System.out.println("Withdrawal from account2 failed.");
        }

        account2.checkBalance();
    }
}
