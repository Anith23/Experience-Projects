class Rectangle {
    private double width;
    private double height;
    private double area;
    private double perimeter;

    // Default constructor
    public Rectangle() {
        System.out.println("This is a Default Constructor");
        height = 10.05;
        width = 20.01;
        findArea();
        findPerimeter();
    }

    // Parameterized constructor
    public Rectangle(double height, double width) {
        System.out.println("This is a parameterized constructor");
        this.height = height;
        this.width = width;
        findArea();
        findPerimeter();
    }

    // Method to find area
    public void findArea() {
        area = height * width;
    }

    // Method to find perimeter
    public void findPerimeter() {
        perimeter = 2 * (height + width);
    }

    // Method to get details
    public void getDetails() {
        System.out.println("Area: " + area);
        System.out.println("Perimeter: " + perimeter);
    }

    public static void main(String[] args) {
        // Create an object using the default constructor
        Rectangle defaultRectangle = new Rectangle();
        System.out.println("Details of Default Rectangle:");
        defaultRectangle.getDetails();

        // Create an object using the parameterized constructor
        Rectangle paramRectangle = new Rectangle(8.5, 12.3);
        System.out.println("\nDetails of Parameterized Rectangle:");
        paramRectangle.getDetails();
    }
}
